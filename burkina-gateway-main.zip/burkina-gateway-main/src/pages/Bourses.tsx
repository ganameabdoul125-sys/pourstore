import { GraduationCap, Calendar, BookOpen, ArrowRight, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import scholarshipImg from "@/assets/scholarship-bg.jpg";

const Bourses = () => {
  const scholarships = [
    {
      id: 1,
      name: "Bourse du Gouvernement Chinois",
      level: "Licence, Master, Doctorat",
      field: "Tous domaines",
      deadline: "Mars 2025",
      description: "Bourse complète couvrant les frais de scolarité, logement et allocation mensuelle.",
      benefits: ["Frais de scolarité gratuits", "Logement fourni", "Allocation mensuelle", "Assurance médicale"],
    },
    {
      id: 2,
      name: "Bourse des Instituts Confucius",
      level: "Tous niveaux",
      field: "Langue et Culture Chinoise",
      deadline: "Avril 2025",
      description: "Programme dédié à l'apprentissage de la langue et de la culture chinoise.",
      benefits: ["Cours de chinois intensifs", "Hébergement inclus", "Allocation mensuelle", "Activités culturelles"],
    },
    {
      id: 3,
      name: "Bourse des Universités Provinciales",
      level: "Master, Doctorat",
      field: "Sciences, Ingénierie, Économie",
      deadline: "Mai 2025",
      description: "Bourses offertes par les meilleures universités chinoises des provinces.",
      benefits: ["Frais de scolarité réduits", "Possibilité de logement", "Réseau professionnel"],
    },
  ];

  const getWhatsAppUrl = (scholarshipName: string) => {
    const message = `Bonjour, je souhaite plus d'informations sur la ${scholarshipName}. Pouvez-vous m'aider avec la procédure de candidature ?`;
    const phoneNumber = "22670000000";
    return `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Hero Section */}
      <div 
        className="relative h-[400px] flex items-center justify-center mb-16"
        style={{
          backgroundImage: `linear-gradient(rgba(26, 54, 93, 0.85), rgba(26, 54, 93, 0.85)), url(${scholarshipImg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="container mx-auto px-4 text-center z-10">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Bourses d'Étude en Chine
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Votre avenir commence ici. Découvrez les opportunités d'études en Chine.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        {/* Introduction */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Pourquoi Étudier en Chine ?</h2>
          <p className="text-muted-foreground text-lg">
            La Chine offre des opportunités exceptionnelles pour les étudiants internationaux. 
            Avec des universités de renommée mondiale, des bourses généreuses et une expérience 
            culturelle unique, c'est le moment idéal pour faire avancer votre carrière.
          </p>
        </div>

        {/* Scholarships List */}
        <div className="space-y-6 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Bourses Disponibles</h2>
          
          {scholarships.map((scholarship) => (
            <Card key={scholarship.id} className="hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 rounded-lg bg-accent/10">
                        <GraduationCap className="w-6 h-6 text-accent" />
                      </div>
                      <CardTitle className="text-2xl">{scholarship.name}</CardTitle>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        {scholarship.level}
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Date limite: {scholarship.deadline}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-1">Domaine d'étude:</h4>
                  <p className="text-muted-foreground">{scholarship.field}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-1">Description:</h4>
                  <p className="text-muted-foreground">{scholarship.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Avantages:</h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {scholarship.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 flex gap-3">
                  <a 
                    href={getWhatsAppUrl(scholarship.name)} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1"
                  >
                    <Button className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white">
                      <MessageCircle className="mr-2 w-4 h-4" />
                      Je suis intéressé(e)
                    </Button>
                  </a>
                  <a href="/contact" className="flex-1">
                    <Button variant="outline" className="w-full">
                      En savoir plus
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Accompaniment Section */}
        <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Notre Accompagnement</h2>
          <p className="text-lg mb-6 max-w-2xl mx-auto opacity-90">
            Nous vous assistons à chaque étape de votre démarche : constitution du dossier, 
            traduction des documents, préparation aux entretiens et assistance pour le visa.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a href="/contact">
              <Button size="lg" variant="secondary" className="font-semibold">
                Demander un Accompagnement
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Bourses;
