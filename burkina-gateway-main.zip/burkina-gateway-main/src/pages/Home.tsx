import { ArrowRight, Package, GraduationCap, Ship } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import heroBg from "@/assets/hero-bg.jpg";
import charcoalImg from "@/assets/charcoal-product.jpg";
import scholarshipImg from "@/assets/scholarship-bg.jpg";
import importExportImg from "@/assets/import-export-bg.jpg";

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative h-[600px] flex items-center justify-center text-center"
        style={{
          backgroundImage: `linear-gradient(rgba(26, 54, 93, 0.85), rgba(26, 54, 93, 0.85)), url(${heroBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="container mx-auto px-4 z-10">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
            Votre Passerelle vers la Chine
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
            Commerce, Éducation & Import/Export - Tous vos projets avec la Chine en un seul endroit
          </p>
          <Link to="/contact">
            <Button size="lg" variant="default" className="bg-accent hover:bg-accent/90 text-white font-semibold px-8 py-6 text-lg">
              Commencer Maintenant
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">
            Nos Services
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Charbon Card */}
            <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <div className="h-48 overflow-hidden">
                <img 
                  src={charcoalImg} 
                  alt="Charbon carré de chicha" 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-accent/10">
                    <Package className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold">Charbon de Qualité</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Charbon carré importé directement de Chine. Longue durée, sans goût, 100% naturel.
                </p>
                <Link to="/charbon">
                  <Button variant="outline" className="w-full group">
                    Découvrir le Charbon
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Bourses Card */}
            <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <div className="h-48 overflow-hidden">
                <img 
                  src={scholarshipImg} 
                  alt="Études en Chine" 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-accent/10">
                    <GraduationCap className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold">Bourses d'Étude</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Accédez aux meilleures universités chinoises. Bourses complètes, accompagnement personnalisé.
                </p>
                <Link to="/bourses">
                  <Button variant="outline" className="w-full group">
                    Voir les Bourses
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Import/Export Card */}
            <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <div className="h-48 overflow-hidden">
                <img 
                  src={importExportImg} 
                  alt="Import/Export" 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-accent/10">
                    <Ship className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold">Import/Export</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Services complets d'importation et d'exportation. Simplifiez vos échanges commerciaux.
                </p>
                <Link to="/contact">
                  <Button variant="outline" className="w-full group">
                    Nos Services
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-6">
            Prêt à Démarrer Votre Projet ?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Contactez-nous dès aujourd'hui et découvrez comment nous pouvons vous aider
          </p>
          <Link to="/contact">
            <Button size="lg" variant="secondary" className="font-semibold px-8 py-6 text-lg">
              Contactez-nous
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
