import { MessageCircle, Package, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import charcoalImg from "@/assets/charcoal-product.jpg";

const Charbon = () => {
  const whatsappMessage = "Bonjour, je suis intéressé par votre charbon carré de chicha. Pouvez-vous me donner plus d'informations sur les prix et la disponibilité ?";
  const phoneNumber = "22670000000";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(whatsappMessage)}`;

  const features = [
    "Longue durée de combustion",
    "Sans goût, sans odeur",
    "100% naturel",
    "Importé directement de Chine",
    "Format carré pratique",
    "Emballage professionnel",
  ];

  return (
    <div className="min-h-screen pt-20 pb-16">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Charbon Carré de Chicha
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Qualité supérieure, directement importé de Chine
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img 
                src={charcoalImg} 
                alt="Charbon carré de chicha" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 rounded-lg bg-accent/10">
                    <Package className="w-8 h-8 text-accent" />
                  </div>
                  <h2 className="text-2xl font-bold">Caractéristiques</h2>
                </div>
                
                <ul className="space-y-3">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Informations Produit</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Format: Carton complet</li>
                  <li>• Type: Charbon cubique</li>
                  <li>• Origine: Chine</li>
                  <li>• Conditionnement: Professionnel</li>
                </ul>
              </CardContent>
            </Card>

            {/* CTA Buttons */}
            <div className="space-y-3">
              <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="block">
                <Button 
                  size="lg" 
                  className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white font-semibold text-lg py-6"
                >
                  <MessageCircle className="mr-2 w-6 h-6" />
                  Commander via WhatsApp
                </Button>
              </a>
              
              <a href="/contact">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="w-full font-semibold text-lg py-6"
                >
                  Demander un Devis
                </Button>
              </a>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="bg-muted/50 rounded-2xl p-8 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4 text-center">Pourquoi Choisir Notre Charbon ?</h2>
          <p className="text-muted-foreground text-center mb-6">
            Nous importons directement de Chine pour vous garantir la meilleure qualité au meilleur prix. 
            Notre charbon carré est spécialement conçu pour une utilisation avec les chichas, offrant une 
            combustion longue et uniforme sans altérer le goût de votre tabac.
          </p>
          <div className="text-center">
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button variant="default" size="lg" className="font-semibold">
                Contactez-nous pour Plus d'Informations
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Charbon;
